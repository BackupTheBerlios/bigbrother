import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class BigBrother extends JFrame{
	private JTextArea display;
	private JPanel p1;
	
	public BigBrother(){
		super("Menu");
		
		Container c = getContentPane();
		p1 = new JPanel();
		p1.setLayout(new BorderLayout());
		
		JMenuBar bar = new JMenuBar(); //cria a barra de menus
		setJMenuBar( bar );
		
		JMenu fileMenu = new JMenu( "File" );
		fileMenu.setMnemonic( 'F' );
		JMenuItem aboutItem = new JMenuItem( "About..." );
		aboutItem.setMnemonic( 'A' );
		
		aboutItem.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent e ){
					JOptionPane.showMessageDialog( BigBrother.this,
					"Exemplo de uso de menus","About", 
					JOptionPane.PLAIN_MESSAGE );
				}
			}
		);
		
		fileMenu.add( aboutItem );
		
		JMenuItem exitItem = new JMenuItem( "Exit" );
		exitItem.setMnemonic('x');
		exitItem.addActionListener(
			new ActionListener(){
				public void actionPerformed( ActionEvent e ){
					System.exit( 0 );
				}
			}
		);
		
		fileMenu.add( exitItem );
		bar.add( fileMenu );
		
		JMenu formatMenu = new JMenu("Format");
		formatMenu.setMnemonic('r');
		
		JMenu subMenu = new JMenu("Colors");
		JMenuItem verde = new JMenuItem("Verde");
		JMenuItem vermelho = new JMenuItem("Vermelho");
		subMenu.add(verde);
		subMenu.add(vermelho);
		formatMenu.add(subMenu);
		
		bar.add(formatMenu);
		
		display = new JTextArea();
		display.setEnabled(false);
		p1.add( new JScrollPane( display ) );
		c.add( p1, BorderLayout.CENTER );

				
		setSize( 800, 550 );
		show();
	}
	
	public static void main( String args[] ){
		BigBrother app = new BigBrother();
		
		app.addWindowListener(
			new WindowAdapter(){
				public void windowClosing( WindowEvent e ){
					System.exit( 0 );
				}
			}
		);
	}
}